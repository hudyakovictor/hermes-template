"""
Experiment Runner — базовый шаблон для всех уровней тестирования
Запуск: python experiment_runner.py --config EXP-XXX/config.yaml
"""

import argparse
import json
import time
import os
from pathlib import Path
from datetime import datetime

import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader

# ============================================================
# RESOURCE CHECK — обязательно перед каждым запуском
# ============================================================

def check_gpu_resources():
    """Pre-flight GPU check"""
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA not available — check driver/PyTorch install")
    
    device_name = torch.cuda.get_device_name(0)
    vram_total = torch.cuda.get_device_properties(0).total_memory / 1e9
    vram_free = (torch.cuda.get_device_properties(0).total_memory - 
                 torch.cuda.memory_allocated(0)) / 1e9
    
    print(f"GPU: {device_name}")
    print(f"VRAM: {vram_free:.1f}GB free / {vram_total:.1f}GB total")
    
    return {"device": device_name, "vram_total_gb": vram_total, "vram_free_gb": vram_free}


# ============================================================
# LEVEL-ADAPTIVE TRAINING CONFIG
# ============================================================

LEVEL_CONFIGS = {
    0: {  # Toy — <5 min
        "precision": "fp32",
        "compile": False,
        "gradient_checkpointing": False,
        "max_params": 1_000_000,
        "batch_size": 512,
        "description": "Toy sanity check"
    },
    1: {  # Small — <1h
        "precision": "bf16",
        "compile": True,
        "gradient_checkpointing": False,
        "max_params": 50_000_000,
        "batch_size": 128,
        "description": "Minimal viable test"
    },
    2: {  # Medium — 2-8h
        "precision": "bf16",
        "compile": True,
        "gradient_checkpointing": True,
        "max_params": 1_000_000_000,
        "batch_size": 32,
        "description": "Mechanistic probe"
    },
    3: {  # Large — 8h+
        "precision": "bf16",
        "compile": True,
        "gradient_checkpointing": True,
        "max_params": None,  # no limit
        "batch_size": 8,
        "description": "Scale validation"
    }
}


# ============================================================
# METRICS TRACKER
# ============================================================

class MetricsTracker:
    def __init__(self, experiment_id: str, seed: int, level: int):
        self.experiment_id = experiment_id
        self.seed = seed
        self.level = level
        self.start_time = time.time()
        self.metrics = {
            "train_loss": [],
            "val_loss": [],
            "test_accuracy": None,
            "generalization_gap": None,
            "peak_vram_gb": 0,
            "gpu_time_seconds": 0,
        }
        
    def update(self, step: int, train_loss: float, val_loss: float = None):
        self.metrics["train_loss"].append({"step": step, "value": float(train_loss)})
        if val_loss is not None:
            self.metrics["val_loss"].append({"step": step, "value": float(val_loss)})
        
        # Track peak VRAM
        if torch.cuda.is_available():
            current_vram = torch.cuda.memory_allocated(0) / 1e9
            self.metrics["peak_vram_gb"] = max(self.metrics["peak_vram_gb"], current_vram)
    
    def finalize(self, test_accuracy: float):
        self.metrics["test_accuracy"] = float(test_accuracy)
        self.metrics["gpu_time_seconds"] = time.time() - self.start_time
        
        if self.metrics["val_loss"] and self.metrics["train_loss"]:
            final_val = self.metrics["val_loss"][-1]["value"]
            final_train = self.metrics["train_loss"][-1]["value"]
            self.metrics["generalization_gap"] = final_val - final_train
        
        return self.metrics
    
    def save(self, output_dir: Path):
        output_dir.mkdir(parents=True, exist_ok=True)
        result_path = output_dir / f"seed_{self.seed}_metrics.json"
        
        result = {
            "experiment_id": self.experiment_id,
            "level": self.level,
            "seed": self.seed,
            "timestamp": datetime.now().isoformat(),
            "metrics": self.metrics
        }
        
        with open(result_path, "w") as f:
            json.dump(result, f, indent=2)
        
        print(f"Results saved: {result_path}")
        return result_path


# ============================================================
# GO/NO-GO DECISION ENGINE
# ============================================================

def evaluate_go_nogo(results: list, level: int, pass_criterion: dict, fail_criterion: dict) -> dict:
    """
    Evaluate results across seeds and decide GO/NO-GO for next level.
    
    pass_criterion example: {"metric": "test_accuracy", "threshold": 0.8, "comparison": ">"}
    fail_criterion example: {"metric": "test_accuracy", "threshold": 0.5, "comparison": "<"}
    """
    values = [r["metrics"].get(pass_criterion["metric"]) for r in results if r["metrics"].get(pass_criterion["metric"])]
    
    if not values:
        return {"decision": "INCONCLUSIVE", "reason": "Metric not found in results"}
    
    mean_val = np.mean(values)
    std_val = np.std(values)
    n_pass = sum(1 for v in values if _compare(v, pass_criterion["threshold"], pass_criterion["comparison"]))
    
    decision = {
        "metric": pass_criterion["metric"],
        "values": values,
        "mean": float(mean_val),
        "std": float(std_val),
        "n_seeds": len(values),
        "n_pass": n_pass,
    }
    
    if level == 0:
        # Toy: even 1 seed with strong signal is enough to proceed
        if n_pass >= 1 and mean_val > pass_criterion["threshold"] * 0.5:
            decision["decision"] = "GO"
            decision["next_level"] = 1
        else:
            decision["decision"] = "NO-GO"
            decision["reason"] = "Weak/no signal at toy level — rethink mechanism"
    
    elif level == 1:
        # Small: need 3/3 seeds
        if n_pass >= 3:
            decision["decision"] = "GO"
            decision["next_level"] = 2
        elif n_pass == 2:
            decision["decision"] = "BORDERLINE"
            decision["reason"] = "2/3 seeds pass — run 2 more seeds before deciding"
        else:
            decision["decision"] = "NO-GO"
            decision["reason"] = "Level 0 signal was noise — kill hypothesis"
    
    elif level == 2:
        # Mechanistic: need mechanism isolated
        if n_pass >= 3:
            decision["decision"] = "GO"
            decision["next_level"] = 3
            decision["note"] = "Consider publication at this point"
        else:
            decision["decision"] = "MODIFIED"
            decision["reason"] = "Effect present but mechanism unclear — refine hypothesis"
    
    return decision


def _compare(value: float, threshold: float, comparison: str) -> bool:
    if comparison == ">":
        return value > threshold
    elif comparison == "<":
        return value < threshold
    elif comparison == ">=":
        return value >= threshold
    elif comparison == "<=":
        return value <= threshold
    return False


# ============================================================
# MAIN RUNNER
# ============================================================

def run_experiment(config: dict, level: int, seeds: list = None):
    """
    Main experiment runner. Call from hypothesis-specific scripts.
    
    config: {experiment_id, model_fn, dataset_fn, train_fn, eval_fn, 
             pass_criterion, fail_criterion, output_dir}
    """
    if seeds is None:
        seeds = [42, 123, 456]
    
    gpu_info = check_gpu_resources()
    level_cfg = LEVEL_CONFIGS[level]
    
    print(f"\n{'='*60}")
    print(f"Experiment: {config['experiment_id']}")
    print(f"Level: {level} — {level_cfg['description']}")
    print(f"Seeds: {seeds}")
    print(f"{'='*60}\n")
    
    results = []
    output_dir = Path(config.get("output_dir", f"experiments/{config['experiment_id']}/results"))
    
    for seed in seeds:
        print(f"\n--- Seed {seed} ---")
        torch.manual_seed(seed)
        np.random.seed(seed)
        
        tracker = MetricsTracker(config["experiment_id"], seed, level)
        
        # Model and data setup
        model = config["model_fn"](level_cfg)
        
        # Apply level-specific optimizations
        if level_cfg["compile"] and hasattr(torch, 'compile'):
            model = torch.compile(model)
        
        train_loader, val_loader, test_loader = config["dataset_fn"](level_cfg)
        
        # Training
        result = config["train_fn"](model, train_loader, val_loader, tracker, level_cfg)
        
        # Evaluation
        test_acc = config["eval_fn"](model, test_loader)
        final_metrics = tracker.finalize(test_acc)
        result_path = tracker.save(output_dir / f"seed_{seed}")
        
        results.append({"seed": seed, "metrics": final_metrics, "path": str(result_path)})
        
        print(f"Seed {seed} complete — accuracy: {test_acc:.4f}, time: {final_metrics['gpu_time_seconds']:.0f}s")
        
        # Early stop if Level 0 shows no signal at all
        if level == 0 and seed == seeds[0]:
            metric_val = final_metrics.get(config["pass_criterion"]["metric"])
            if metric_val is not None and not _compare(metric_val, config["pass_criterion"]["threshold"] * 0.3, ">"):
                print("\nLevel 0, Seed 1: No signal detected — stopping early to save GPU time")
                break
    
    # Go/No-Go decision
    decision = evaluate_go_nogo(results, level, config["pass_criterion"], config["fail_criterion"])
    
    # Save summary
    summary = {
        "experiment_id": config["experiment_id"],
        "level": level,
        "gpu_info": gpu_info,
        "level_config": level_cfg,
        "seeds_run": [r["seed"] for r in results],
        "decision": decision,
        "timestamp": datetime.now().isoformat()
    }
    
    summary_path = output_dir / "summary.json"
    output_dir.mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"DECISION: {decision['decision']}")
    if "next_level" in decision:
        print(f"→ Proceed to Level {decision['next_level']}")
    if "reason" in decision:
        print(f"Reason: {decision['reason']}")
    print(f"{'='*60}\n")
    
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to config.yaml")
    parser.add_argument("--level", type=int, default=0, help="Experiment level 0-3")
    parser.add_argument("--seeds", nargs="+", type=int, default=[42, 123, 456])
    args = parser.parse_args()
    
    print("Use experiment_runner.run_experiment() from your hypothesis-specific script.")
    print("This base runner provides the infrastructure; hypothesis logic goes in EXP-XXX/train.py")

