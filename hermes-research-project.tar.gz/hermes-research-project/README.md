# HERMES RESEARCH PROJECT
# AI-Powered Scientific Discovery Engine
# RTX 5090 | Windows | Hermes Agent

---

## Структура проекта

```
hermes-research-project/
├── agent/
│   ├── constitution/
│   │   ├── SYSTEM_CONSTITUTION.md   ← главный файл инструкций агента
│   │   ├── AGENT_MODES.md           ← 5 режимов работы агента
│   │   ├── HERMES_CONFIG.yaml       ← конфиг для ~/.hermes/config.yaml
│   │   ├── HYPOTHESIS_TEMPLATE.yaml ← шаблон для каждой гипотезы
│   │   └── SCORING_RUBRIC.md        ← 15 факторов оценки
│   └── skills/
│       ├── research_skill.md        ← /skill research
│       └── experiment_skill.md      ← /skill experiment
├── hypotheses/
│   └── H-001.yaml  ← (будет создано)
├── signals/
│   └── (сырые аномалии)
├── experiments/
│   ├── experiment_runner.py         ← базовый runner
│   └── EXP-001/  ← (будет создано)
├── results/
│   └── (вердикты по экспериментам)
├── memory/
│   └── (knowledge store проекта)
└── logs/
    └── (agent runs)
```

---

## Быстрый старт

### 1. Установка Hermes (Windows, native)
```powershell
# PowerShell as Administrator
irm https://raw.githubusercontent.com/NousResearch/hermes-agent/main/install.ps1 | iex
```

### 2. Копирование конфига
```
Скопировать agent/constitution/HERMES_CONFIG.yaml → C:\Users\<USER>\.hermes\config.yaml
```

### 3. Установка провайдера
```bash
hermes setup  # выбрать провайдер и вставить API ключ
```

### 4. Установить skills проекта
```bash
# Скопировать skills в ~/.hermes/skills/
copy agent/skills/research_skill.md %USERPROFILE%\.hermes\skills\research.md
copy agent/skills/experiment_skill.md %USERPROFILE%\.hermes\skills\experiment.md
```

### 5. Запуск агента
```bash
# Открыть папку проекта и запустить Hermes
cd C:\hermes-research-project
hermes

# Активировать research mode:
# /skill research
# Затем: "Начни signal mining по теме: [тема]"
```

---

## Workflow

```
START
  ↓
/skill research
  ↓
[MODE: SIGNAL_MINER] — собрать 5+ сигналов
  ↓
/skill research → [MODE: HYPOTHESIS_ARCHITECT]
  ↓
Kill Stage → отсеять слабые гипотезы
  ↓
/skill experiment → [MODE: EXPERIMENT_DISPATCHER]
  ↓
Level 0 (< 5 min GPU) → GO/NO-GO
  ↓ (GO)
Level 1 (< 1h GPU, 3 seeds) → GO/NO-GO
  ↓ (GO)
Level 2 (2-8h, механистический) → ALIVE/DEAD/MODIFIED
  ↓ (ALIVE)
Level 3 (scale validation) → Publication candidate
```

---

## PyTorch Setup для RTX 5090

```bash
# Python 3.11/3.12 в отдельном venv
python -m venv .venv
.venv\Scripts\activate

# PyTorch с CUDA (проверь актуальную версию на pytorch.org)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128

# Исследовательский стек
pip install transformers datasets einops wandb scipy scikit-learn matplotlib

# Проверка
python -c "import torch; print(torch.cuda.get_device_name(0))"
# → NVIDIA GeForce RTX 5090
```

---

## Оценка: 97/100 по 15 факторам

Полная таблица: agent/constitution/SCORING_RUBRIC.md

