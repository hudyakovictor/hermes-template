# EXPERIMENT SKILL — HERMES AGENT
# Этот файл загружается как skill через /skill experiment

---

## Skill: GPU Experiment Runner

Когда загружен этот skill, агент управляет каскадным тестированием гипотез на RTX 5090.

### Pre-flight checklist (ВСЕГДА перед запуском):
```bash
# Агент обязан выполнить перед каждым экспериментом:
nvidia-smi  # проверить доступность GPU, температуру, VRAM
nvidia-smi --query-gpu=name,memory.total,memory.free --format=csv  # VRAM check
python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"
```

### GPU Resource Tiers для RTX 5090 (32GB VRAM):

```
TIER 0 — Toy (< 5 min):
  batch_size: 256-512
  model_params: < 1M
  precision: fp32 (нет смысла в fp16 для toy)
  torch.compile: False (overhead не стоит)
  
TIER 1 — Small (< 1h):
  batch_size: 64-256  
  model_params: 1M-50M
  precision: bf16
  torch.compile: True (экономит ~20%)
  gradient_checkpointing: False

TIER 2 — Medium (1-8h):
  batch_size: 16-64 + gradient accumulation
  model_params: 50M-1B
  precision: bf16 + autocast
  torch.compile: True
  gradient_checkpointing: True (если > 4B параметров)
  
TIER 3 — Large (8h+):
  batch_size: 4-16 + gradient accumulation steps=8
  model_params: 1B+
  precision: bf16
  torch.compile: True  
  gradient_checkpointing: True
  offload_to_cpu: опционально для weights
```

### Experiment directory structure:
```
/experiments/EXP-XXX/
  ├── config.yaml          # все параметры
  ├── run.sh               # launch script
  ├── model.py             # архитектура (если custom)
  ├── dataset.py           # генерация / загрузка данных
  ├── train.py             # training loop
  ├── evaluate.py          # metrics
  └── results/
      ├── seed_1/          # отдельно по seed
      ├── seed_2/
      ├── seed_3/
      └── summary.json     # агрегированные метрики
```

### Обязательные метрики для КАЖДОГО эксперимента:
```python
metrics_to_log = {
    # Task metrics (domain-specific)
    "train_loss": [],
    "val_loss": [],
    "test_accuracy": float,
    
    # Mechanistic probes (для исследовательских целей)
    "generalization_gap": val_loss - train_loss,
    "sample_efficiency": accuracy_at_10pct_data,
    "stability": std_across_seeds,
    
    # Resource metrics
    "gpu_time_seconds": float,
    "peak_vram_gb": float,
    "total_flops": float,  # если можно посчитать
}
```

### Go / No-Go decision tree:
```
Level 0 result:
  effect_size > 0.5 AND p_value < 0.1 (даже 1 seed) → GO to Level 1
  effect_size < 0.1 → KILL hypothesis
  0.1 < effect_size < 0.5 → RETHINK mechanism, try modified version

Level 1 result:
  effect reproduced in 3/3 seeds AND delta > 2σ → GO to Level 2
  reproduced in 2/3 seeds → run 2 more seeds before deciding
  reproduced in 0/3 seeds → KILL (Level 0 was noise)

Level 2 result:
  mechanism isolated + ablation confirms → ALIVE + consider publication
  effect exists but mechanism unclear → MODIFIED hypothesis
  effect disappears under ablation → KILL (was confound)
```

### Постоянный мониторинг:
```bash
# Агент запускает в фоне во время обучения:
watch -n 30 nvidia-smi  # каждые 30 сек
tensorboard --logdir=experiments/EXP-XXX/results/  # для визуализации
```

